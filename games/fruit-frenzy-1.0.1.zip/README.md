# Fruit Frenzy

A portrait 2D hyper-casual fruit-catching game.

## Controls
**TAP directly on a fruit to catch it.**

Tap once anywhere to start the game. During gameplay, tap the fruit itself before it falls away:
- Each caught fruit increases the score.
- Consecutive catches build a combo.
- Missing three fruits ends the run.
- Different fruits award different points.

The package is directly browser-playable through `index.html` and also contains the `src/main.ts` entry for the platform's Vite + Phaser pipeline.
